var searchData=
[
  ['kernel_5fbroadcast_0',['kernel_broadcast',['../kernel__cc_8h.html#a6ab8c1febc779de0c176d4e8a101ec5b',1,'kernel_broadcast(CondVar *cv):&#160;kernel_cc.c'],['../kernel__cc_8c.html#a6ab8c1febc779de0c176d4e8a101ec5b',1,'kernel_broadcast(CondVar *cv):&#160;kernel_cc.c']]],
  ['kernel_5fcc_2ec_1',['kernel_cc.c',['../kernel__cc_8c.html',1,'']]],
  ['kernel_5fcc_2eh_2',['kernel_cc.h',['../kernel__cc_8h.html',1,'']]],
  ['kernel_5fdev_2eh_3',['kernel_dev.h',['../kernel__dev_8h.html',1,'']]],
  ['kernel_5flock_4',['kernel_lock',['../kernel__cc_8h.html#a64cbb83e8857ffaf703722363ac94f05',1,'kernel_lock():&#160;kernel_cc.c'],['../kernel__cc_8c.html#a64cbb83e8857ffaf703722363ac94f05',1,'kernel_lock():&#160;kernel_cc.c']]],
  ['kernel_5fmutex_5',['kernel_mutex',['../kernel__cc_8c.html#a57ffb2dcd44b56da47dc03b2f85d9480',1,'kernel_cc.c']]],
  ['kernel_5fproc_2eh_6',['kernel_proc.h',['../kernel__proc_8h.html',1,'']]],
  ['kernel_5fsched_2eh_7',['kernel_sched.h',['../kernel__sched_8h.html',1,'']]],
  ['kernel_5fsignal_8',['kernel_signal',['../kernel__cc_8c.html#a167cdb3f2a2285becf553405210eb08a',1,'kernel_signal(CondVar *cv):&#160;kernel_cc.c'],['../kernel__cc_8h.html#a167cdb3f2a2285becf553405210eb08a',1,'kernel_signal(CondVar *cv):&#160;kernel_cc.c']]],
  ['kernel_5fsleep_9',['kernel_sleep',['../kernel__cc_8c.html#aeafd158aa175ab53b85bc55dc4bbd962',1,'kernel_sleep(Thread_state newstate, enum SCHED_CAUSE cause):&#160;kernel_cc.c'],['../kernel__cc_8h.html#ac108cbd1eb069858a5ed9e576069c464',1,'kernel_sleep(Thread_state state, enum SCHED_CAUSE cause):&#160;kernel_cc.c']]],
  ['kernel_5fstreams_2eh_10',['kernel_streams.h',['../kernel__streams_8h.html',1,'']]],
  ['kernel_5funlock_11',['kernel_unlock',['../kernel__cc_8c.html#a8ca062a9a1c570f34398bd177cb96e58',1,'kernel_unlock():&#160;kernel_cc.c'],['../kernel__cc_8h.html#a8ca062a9a1c570f34398bd177cb96e58',1,'kernel_unlock():&#160;kernel_cc.c']]],
  ['kernel_5fwait_5fwchan_12',['kernel_wait_wchan',['../kernel__cc_8c.html#a1fad5a21e5010939e1e0ad711192bc6c',1,'kernel_wait_wchan(CondVar *cv, enum SCHED_CAUSE cause, const char *wchan_name, TimerDuration timeout):&#160;kernel_cc.c'],['../kernel__cc_8h.html#abe7f999775e4f5a56201bf88a9eeb2a1',1,'kernel_wait_wchan(CondVar *cv, enum SCHED_CAUSE cause, const char *wchan, TimerDuration timeout):&#160;kernel_cc.c']]]
];
