var searchData=
[
  ['open_0',['Open',['../structfile__operations.html#a6376dcf4623ab43032b6269eaddafd56',1,'file_operations']]],
  ['owner_5fpcb_1',['owner_pcb',['../structthread__control__block.html#a74aa312623cb8be2bc719d5210b58c04',1,'thread_control_block']]]
];
