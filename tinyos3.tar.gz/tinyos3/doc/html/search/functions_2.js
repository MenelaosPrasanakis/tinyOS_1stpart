var searchData=
[
  ['close_0',['Close',['../group__syscalls.html#ga82187e2e98af053a2ab6cb516e9e7f5a',1,'tinyos.h']]],
  ['cond_5fbroadcast_1',['cond_broadcast',['../group__syscalls.html#ga8196aa2a48cad90742f254cc3b8fd351',1,'Cond_Broadcast(CondVar *cv):&#160;kernel_cc.c'],['../group__syscalls.html#ga8196aa2a48cad90742f254cc3b8fd351',1,'Cond_Broadcast(CondVar *):&#160;kernel_cc.c']]],
  ['cond_5fsignal_2',['cond_signal',['../group__syscalls.html#ga43f64f8be273d2fe77d7de5f4b81e22d',1,'Cond_Signal(CondVar *cv):&#160;kernel_cc.c'],['../group__syscalls.html#ga43f64f8be273d2fe77d7de5f4b81e22d',1,'Cond_Signal(CondVar *):&#160;kernel_cc.c']]],
  ['cond_5ftimedwait_3',['cond_timedwait',['../group__syscalls.html#ga4e955b769339be9ea6a0c1bd4151c48f',1,'Cond_TimedWait(Mutex *mutex, CondVar *cv, timeout_t timeout):&#160;kernel_cc.c'],['../group__syscalls.html#ga4e955b769339be9ea6a0c1bd4151c48f',1,'Cond_TimedWait(Mutex *mx, CondVar *cv, timeout_t timeout):&#160;kernel_cc.c']]],
  ['cond_5fwait_4',['cond_wait',['../group__syscalls.html#ga970dca2210b3f2ec8aedab7f542a9bf4',1,'Cond_Wait(Mutex *mutex, CondVar *cv):&#160;kernel_cc.c'],['../group__syscalls.html#ga970dca2210b3f2ec8aedab7f542a9bf4',1,'Cond_Wait(Mutex *mx, CondVar *cv):&#160;kernel_cc.c']]],
  ['connect_5',['Connect',['../group__syscalls.html#ga747ceadd43e9a4c72b08fffbadaefbdd',1,'tinyos.h']]],
  ['cpu_5fcore_5fbarrier_5fsync_6',['cpu_core_barrier_sync',['../bios_8h.html#ab8f96f6027a2276735b4a221a56ed786',1,'bios.h']]],
  ['cpu_5fcore_5fhalt_7',['cpu_core_halt',['../bios_8h.html#a3e2c9a3aea40c8eeaa723ee35caace06',1,'bios.h']]],
  ['cpu_5fcore_5frestart_8',['cpu_core_restart',['../bios_8h.html#a9191a31f24c07b8282a3c8edbba24ee0',1,'bios.h']]],
  ['cpu_5fcore_5frestart_5fall_9',['cpu_core_restart_all',['../bios_8h.html#aa82b1a876663da26cbf511bcfb06404d',1,'bios.h']]],
  ['cpu_5fcore_5frestart_5fone_10',['cpu_core_restart_one',['../bios_8h.html#a7eeccd43040cc43ac977f649d639a3e9',1,'bios.h']]],
  ['cpu_5fcores_11',['cpu_cores',['../bios_8h.html#aa02a29e5c8a1f4d68413eea0aaa09fba',1,'bios.h']]],
  ['cpu_5fdisable_5finterrupts_12',['cpu_disable_interrupts',['../bios_8h.html#afec1cd080e34866f6497b18f1bac8e8f',1,'bios.h']]],
  ['cpu_5fenable_5finterrupts_13',['cpu_enable_interrupts',['../bios_8h.html#a10055a90cf57a2a22fa9193922f9f2a8',1,'bios.h']]],
  ['cpu_5fici_14',['cpu_ici',['../bios_8h.html#a719b0f9f8854d21436c96931ba1caf59',1,'bios.h']]],
  ['cpu_5finitialize_5fcontext_15',['cpu_initialize_context',['../bios_8h.html#a825ac4a4bcf2ef8d3c9bb48d5434c161',1,'bios.h']]],
  ['cpu_5finterrupt_5fhandler_16',['cpu_interrupt_handler',['../bios_8h.html#a0cf5c5e80f04d98362346e6ec770022d',1,'bios.h']]],
  ['cpu_5finterrupts_5fenabled_17',['cpu_interrupts_enabled',['../bios_8h.html#af61d7c032b12e989a7005d830f71054f',1,'bios.h']]],
  ['cpu_5fswap_5fcontext_18',['cpu_swap_context',['../bios_8h.html#a78a3870d56e6867224909cf226c2e90a',1,'bios.h']]],
  ['createthread_19',['CreateThread',['../group__syscalls.html#ga284070b5fddcc3653e146e63fcbfe6e3',1,'tinyos.h']]],
  ['cur_5fthread_20',['cur_thread',['../group__scheduler.html#ga163aab2d0732e468f266619b5f6ef380',1,'cur_thread():&#160;kernel_sched.c'],['../group__scheduler.html#ga163aab2d0732e468f266619b5f6ef380',1,'cur_thread():&#160;kernel_sched.c']]]
];
