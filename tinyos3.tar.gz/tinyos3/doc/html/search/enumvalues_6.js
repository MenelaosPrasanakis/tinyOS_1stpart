var searchData=
[
  ['normal_5fthread_0',['NORMAL_THREAD',['../group__scheduler.html#gga18795bc1ab00161fc27ce34b1895fb03a1d3bb8be1deb6ac7be94fea88e1ed76b',1,'kernel_sched.h']]]
];
