var searchData=
[
  ['sched_5fnode_0',['sched_node',['../structthread__control__block.html#add433b079e04053fe70fdd2b92e1d6ad',1,'thread_control_block']]],
  ['serial_5fin_1',['serial_in',['../structvm__config.html#a4e88489ff8b42ce872cf1189673e2cc7',1,'vm_config']]],
  ['serial_5fout_2',['serial_out',['../structvm__config.html#a53a39f43c3368fed51748c0b156a942c',1,'vm_config']]],
  ['serialno_3',['serialno',['../structvm__config.html#a76113e6dea0361ab0e1dda35bf29b7bf',1,'vm_config']]],
  ['show_5ftests_4',['show_tests',['../structprogram__arguments.html#a373cc9d546fdd5ca2c75e42300caf2e6',1,'program_arguments']]],
  ['state_5',['state',['../structthread__control__block.html#affd872365cf4768fa1c9bd1e196bb97c',1,'thread_control_block::state'],['../structSymposiumTable.html#a70507f28df670d0db2e59fc65309af08',1,'SymposiumTable::state']]],
  ['streamfunc_6',['streamfunc',['../structfile__control__block.html#aa49f26d3baceeb074fa00f9e5caf978b',1,'file_control_block']]],
  ['streamobj_7',['streamobj',['../structfile__control__block.html#a1460eb54b4a65e747b9b9ec3f6a798d6',1,'file_control_block']]],
  ['symp_8',['symp',['../structSymposiumTable.html#a4089e2778ba23eb79c4785eb5702f70f',1,'SymposiumTable']]]
];
