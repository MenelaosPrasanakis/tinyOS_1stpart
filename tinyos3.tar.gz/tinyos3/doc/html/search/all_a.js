var searchData=
[
  ['ici_0',['ICI',['../bios_8h.html#a137af7bce5ff764f5c0aa4550086deaaab4019255561cb4b48789d55c079e1709',1,'bios.h']]],
  ['id_1',['id',['../structcore__control__block.html#a5208867f309bdd1656fd473f38b30bfe',1,'core_control_block']]],
  ['idle_5fthread_2',['idle_thread',['../structcore__control__block.html#a6dd29dab4a95ce740f45370345408c52',1,'core_control_block::idle_thread'],['../group__scheduler.html#gga18795bc1ab00161fc27ce34b1895fb03abc11b4e4eba50c875d7ed6bc34090dd3',1,'IDLE_THREAD:&#160;kernel_sched.h']]],
  ['init_3',['INIT',['../group__scheduler.html#gga6c969c169777f82c104cf73e501df70fa0cb1b2c6a7db1f1084886c98909a3f36',1,'kernel_sched.h']]],
  ['initialize_5fdevices_4',['initialize_devices',['../group__dev.html#ga840b5c2460abea4a19a201f7d6d035c8',1,'initialize_devices():&#160;kernel_dev.c'],['../group__dev.html#ga840b5c2460abea4a19a201f7d6d035c8',1,'initialize_devices():&#160;kernel_dev.c']]],
  ['initialize_5ffiles_5',['initialize_files',['../group__streams.html#ga147537248d983b0cc6cc7e8b39245f09',1,'initialize_files():&#160;kernel_streams.c'],['../group__streams.html#ga147537248d983b0cc6cc7e8b39245f09',1,'initialize_files():&#160;kernel_streams.c']]],
  ['initialize_5fprocesses_6',['initialize_processes',['../group__proc.html#ga82948cbeb57bb0b6e15d1f14f06a2db3',1,'initialize_processes():&#160;kernel_proc.c'],['../group__proc.html#ga82948cbeb57bb0b6e15d1f14f06a2db3',1,'initialize_processes():&#160;kernel_proc.c']]],
  ['initialize_5fscheduler_7',['initialize_scheduler',['../group__scheduler.html#ga244fb594301322e79d11a7844c759bba',1,'initialize_scheduler():&#160;kernel_sched.c'],['../group__scheduler.html#ga244fb594301322e79d11a7844c759bba',1,'initialize_scheduler(void):&#160;kernel_sched.c']]],
  ['interrupt_8',['interrupt',['../bios_8h.html#a137af7bce5ff764f5c0aa4550086deaa',1,'Interrupt:&#160;bios.h'],['../bios_8h.html#adae0801dc227f7fab2d61d0b7c9e9643',1,'Interrupt:&#160;bios.h']]],
  ['interrupt_5fhandler_9',['interrupt_handler',['../bios_8h.html#a11aeb47c6c66d331acd12556d0d4aedc',1,'bios.h']]],
  ['interrupts_10',['Interrupts',['../bios_8h.html#autotoc_md1',1,'']]],
  ['intrusive_20lists_11',['Intrusive lists',['../group__rlists.html#autotoc_md30',1,'']]],
  ['is_5frlist_5fempty_12',['is_rlist_empty',['../group__rlists.html#gaf60549214daf0df46bcd1a0d5ba5b661',1,'util.h']]],
  ['isdebuggerattached_13',['isDebuggerAttached',['../group__Testing.html#ga106e4293a3520dae79707bdf492dc68b',1,'unit_testing.h']]],
  ['its_14',['its',['../structthread__control__block.html#a68760c9f4ba9130ee8489d3e0bc2ec15',1,'thread_control_block']]]
];
