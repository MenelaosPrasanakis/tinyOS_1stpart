var searchData=
[
  ['bios_5fcancel_5ftimer_0',['bios_cancel_timer',['../bios_8h.html#a27768c037d72b51415b836bd93196df2',1,'bios.h']]],
  ['bios_5fclock_1',['bios_clock',['../bios_8h.html#a78addcd72c31fb32d46cc51fe01a86b4',1,'bios.h']]],
  ['bios_5fread_5fserial_2',['bios_read_serial',['../bios_8h.html#a04ebe8b1d424c0ef473db751f7b79fbb',1,'bios.h']]],
  ['bios_5fserial_5finterrupt_5fcore_3',['bios_serial_interrupt_core',['../bios_8h.html#a3d9df4f1db5a1d99720f327668726e2b',1,'bios.h']]],
  ['bios_5fserial_5fports_4',['bios_serial_ports',['../bios_8h.html#af69405820033d3f2e8033af258f47ea2',1,'bios.h']]],
  ['bios_5fset_5ftimer_5',['bios_set_timer',['../bios_8h.html#a01f7a35679bdda42fff3da6ae6e5664b',1,'bios.h']]],
  ['bios_5fwrite_5fserial_6',['bios_write_serial',['../bios_8h.html#a97bde2ebd5f9d86c0085aacaa5e5d287',1,'bios.h']]],
  ['boot_7',['boot',['../group__syscalls.html#ga31d9ee7df9665928617a9f9c0cc6d361',1,'boot(uint ncores, uint nterm, Task boot_task, int argl, void *args):&#160;kernel_init.c'],['../group__syscalls.html#ga31d9ee7df9665928617a9f9c0cc6d361',1,'boot(unsigned int ncores, unsigned int terminals, Task boot_task, int argl, void *args):&#160;kernel_init.c']]]
];
