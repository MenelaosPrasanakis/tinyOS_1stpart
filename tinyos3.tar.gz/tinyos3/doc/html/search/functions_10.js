var searchData=
[
  ['vm_5fboot_0',['vm_boot',['../bios_8h.html#a3474751482bc2a9a40597f66fe35f630',1,'bios.h']]],
  ['vm_5fconfig_5fterminals_1',['vm_config_terminals',['../bios_8h.html#af72e3b1217697a5ae7ecf22e1d1d078a',1,'bios.h']]],
  ['vm_5fconfigure_2',['vm_configure',['../bios_8h.html#a0642848175ea5155275f9a298dd2475e',1,'bios.h']]],
  ['vm_5frun_3',['vm_run',['../bios_8h.html#a37f8796b7357cdfedc482c0b05c6a115',1,'bios.h']]]
];
