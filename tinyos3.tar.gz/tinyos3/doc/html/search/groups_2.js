var searchData=
[
  ['for_20checking_20system_20calls_0',['Macros for checking system calls.',['../group__check__macros.html',1,'']]]
];
