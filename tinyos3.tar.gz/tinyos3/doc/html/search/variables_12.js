var searchData=
[
  ['valgrind_5fstack_5fid_0',['valgrind_stack_id',['../structthread__control__block.html#ad8a2da36c0ad775c12c5f66f4fec9d41',1,'thread_control_block']]],
  ['verbose_1',['verbose',['../structprogram__arguments.html#ab075ba9c1c9d3b650c7490717ed6391e',1,'program_arguments']]]
];
