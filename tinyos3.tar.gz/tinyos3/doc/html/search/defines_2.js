var searchData=
[
  ['preempt_5foff_0',['preempt_off',['../kernel__cc_8h.html#af936bcf607a61848cfea21c119f30905',1,'kernel_cc.h']]],
  ['preempt_5fon_1',['preempt_on',['../kernel__cc_8h.html#ac8efed506a60c7c6f02514e878a4004b',1,'kernel_cc.h']]]
];
