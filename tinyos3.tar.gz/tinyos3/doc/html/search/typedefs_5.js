var searchData=
[
  ['pcb_0',['pcb',['../group__proc.html#ga91aaadf0c3f9cef2293a99c69795323f',1,'PCB:&#160;kernel_proc.h'],['../group__rlists.html#ga91aaadf0c3f9cef2293a99c69795323f',1,'PCB:&#160;util.h']]],
  ['pid_5fstate_1',['pid_state',['../group__proc.html#ga8b605a2dd67e6304da5b7cccb6ea8e61',1,'kernel_proc.h']]],
  ['pid_5ft_2',['Pid_t',['../group__syscalls.html#gafac07f3170763932fac97b6eab2c3984',1,'tinyos.h']]],
  ['pipe_5ft_3',['pipe_t',['../group__syscalls.html#gadcee7249ce0d32b3efb6887e14ca40a8',1,'tinyos.h']]],
  ['port_5ft_4',['port_t',['../group__syscalls.html#ga13894e5a2ffd5febb7aeb90e87239d61',1,'tinyos.h']]],
  ['procinfo_5',['procinfo',['../group__syscalls.html#gad5837ec612b422af3385532de2a70c96',1,'tinyos.h']]],
  ['program_6',['Program',['../tinyoslib_8h.html#ab518accf2c30e915a8250c0ae308aefd',1,'tinyoslib.h']]]
];
