var searchData=
[
  ['dcb_0',['dcb',['../group__dev.html#ga5b4de7b0c72db6219c5a6dda2466181f',1,'DCB:&#160;kernel_dev.h'],['../group__rlists.html#ga5b4de7b0c72db6219c5a6dda2466181f',1,'DCB:&#160;util.h']]],
  ['default_5ftimeout_1',['DEFAULT_TIMEOUT',['../group__Testing.html#gaad2dd72565852b91c809cd4685833b17',1,'unit_testing.h']]],
  ['dependencies_2',['dependencies',['../index.html#autotoc_md18',1,'Build dependencies'],['../md_manhelp.html#autotoc_md12',1,'Re-making the dependencies']]],
  ['description_3',['description',['../structTest.html#a294ca3f1114240c908f66216afcad783',1,'Test::description'],['../md_manhelp.html#autotoc_md7',1,'DESCRIPTION']]],
  ['dev_5ffops_4',['dev_fops',['../structdevice__control__block.html#a2945d5da96f40ff7fae94e295624a7c7',1,'device_control_block']]],
  ['dev_5fmax_5',['DEV_MAX',['../group__dev.html#gga879ceac20e83b2375e5b49f4379b0c90a4d07dfbc7e68d26e2d92773a37381ce7',1,'kernel_dev.h']]],
  ['dev_5fnull_6',['DEV_NULL',['../group__dev.html#gga879ceac20e83b2375e5b49f4379b0c90a8ca9ed7c2fc080b6706582ccf828b08f',1,'kernel_dev.h']]],
  ['dev_5fserial_7',['DEV_SERIAL',['../group__dev.html#gga879ceac20e83b2375e5b49f4379b0c90adb43c91cf279ccd4510abaed9425bacc',1,'kernel_dev.h']]],
  ['device_5fcontrol_5fblock_8',['device_control_block',['../structdevice__control__block.html',1,'']]],
  ['device_5fno_9',['device_no',['../group__dev.html#ga0808cf584a510e0eff6908a5313ce296',1,'device_no(Device_type major):&#160;kernel_dev.c'],['../group__dev.html#ga0808cf584a510e0eff6908a5313ce296',1,'device_no(Device_type major):&#160;kernel_dev.c']]],
  ['device_5fopen_10',['device_open',['../group__dev.html#ga6d8e08550640c9819aa07b6bba9fa6ed',1,'device_open(Device_type major, uint minor, void **obj, file_ops **ops):&#160;kernel_dev.c'],['../group__dev.html#ga6d8e08550640c9819aa07b6bba9fa6ed',1,'device_open(Device_type major, uint minor, void **obj, file_ops **ops):&#160;kernel_dev.c']]],
  ['device_5ftype_11',['Device_type',['../group__dev.html#ga879ceac20e83b2375e5b49f4379b0c90',1,'kernel_dev.h']]],
  ['devices_12',['Devices',['../group__dev.html',1,'']]],
  ['devnum_13',['devnum',['../structdevice__control__block.html#a25d8f038a1c6d41f445d078276117fba',1,'device_control_block']]],
  ['documentation_14',['Building the documentation',['../md_manhelp.html#autotoc_md15',1,'']]],
  ['dup2_15',['Dup2',['../group__syscalls.html#gacc048c60209e2dfb4b5cfc1c3f21aa88',1,'tinyos.h']]]
];
