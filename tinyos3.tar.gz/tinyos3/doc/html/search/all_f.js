var searchData=
[
  ['of_20tests_0',['Types of tests',['../group__Testing.html#autotoc_md22',1,'']]],
  ['on_1',['Building with full optimizations on',['../md_manhelp.html#autotoc_md11',1,'']]],
  ['open_2',['Open',['../structfile__operations.html#a6376dcf4623ab43032b6269eaddafd56',1,'file_operations']]],
  ['openinfo_3',['OpenInfo',['../group__syscalls.html#gaf326b11574cdc84a9e21b9d860076821',1,'tinyos.h']]],
  ['opennull_4',['OpenNull',['../group__syscalls.html#ga39805b4ae668b715fb43f0f1e6ce8c45',1,'tinyos.h']]],
  ['openterminal_5',['OpenTerminal',['../group__syscalls.html#ga6ea2b586a8dfcfc1e7065e1664a0fb35',1,'tinyos.h']]],
  ['optimizations_20on_6',['Building with full optimizations on',['../md_manhelp.html#autotoc_md11',1,'']]],
  ['optional_20test_20parameters_7',['Optional test parameters',['../group__Testing.html#autotoc_md25',1,'']]],
  ['overview_8',['overview',['../group__Testing.html#autotoc_md19',1,'Overview'],['../group__rlists.html#autotoc_md27',1,'Overview']]],
  ['owner_5fpcb_9',['owner_pcb',['../structthread__control__block.html#a74aa312623cb8be2bc719d5210b58c04',1,'thread_control_block']]]
];
