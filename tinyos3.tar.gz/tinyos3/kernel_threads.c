
#include "tinyos.h"
#include "kernel_sched.h"
#include "kernel_proc.h"
#include "kernel_cc.h"

// Find which PTCB (Process Thread Control Block) the thread belongs to based on its Tid (thread ID).
PTCB* find_ptcb(Tid_t tid) {
    // Cast the provided thread ID to a PTCB pointer.
    PTCB* ptcb = (PTCB*)tid;

    // Check if this PTCB exists in the current process's thread list.
    if (rlist_find(&CURPROC->ptcb_list, ptcb, NULL))
        return ptcb;   // If found, return the PTCB.
    else
        return NULL;   // If not found, return NULL to indicate failure.
}

// Function called by spawn_thread to initialize and run a new thread.
// This function never stops on its own; it runs the task and exits.
void initialize_thread() {
    // Get the current PTCB by accessing the current thread's PTCB pointer.
    PTCB* ptcb = CURTHREAD->ptcb;
    assert(ptcb != NULL);  // Ensure that the PTCB is not NULL.

    // Initialize local variables with task, argument length, and arguments from the PTCB.
    Task task = ptcb->task;
    int argl = ptcb->argl;
    void* args = ptcb->args;

    // Execute the task with the provided arguments and capture the exit value.
    int exitval = task(argl, args);

    // Call ThreadExit with the exit value, signaling the thread has finished.
    ThreadExit(exitval);
}

/** 
  @brief Create a new thread in the current process.
  */
Tid_t sys_CreateThread(Task task, int argl, void* args)
{
  if (task != NULL) {
    // Allocate memory for a new PTCB (Process Thread Control Block).
    PTCB* ptcb = (PTCB *)xmalloc(sizeof(PTCB));

    // For efficiency, use the main thread instance of the current process's TCB (Thread Control Block).
    TCB* tcb = CURPROC->main_thread;

    /* Initialize the other attributes of the PTCB */
    ptcb->ref_count = 1;            // Set the reference count to 1, indicating one active reference to this PTCB.
    ptcb->tcb = tcb;                 // Link the PTCB to the TCB (Thread Control Block).
    ptcb->task = task;               // Assign the task function to the PTCB.
    ptcb->argl = argl;               // Set the argument length for the task.
    ptcb->args = (args == NULL) ? NULL : args; // Assign args if not NULL; otherwise, set it to NULL.
    ptcb->exited = 0;                // Initialize exited status to 0 (thread is not exited).
    ptcb->detached = 0;              // Initialize detached status to 0 (thread is not detached).
    ptcb->exit_val = CURPROC->exitval; // Set the exit value from the current process.
    ptcb->exit_cv = COND_INIT;       // Initialize the condition variable for signaling thread exit.

    // Increment the process's thread count as we are adding a new thread.
    CURPROC->thread_count++;

    // Link the current thread's TCB to the new PTCB.
    CURTHREAD->ptcb = ptcb;

    // Create a new TCB for the thread and associate it with the process and PTCB.
    TCB *new_tcb = spawn_thread(CURPROC, initialize_thread); // Create and initialize the new thread.
    // assert(new_tcb != NULL); // Uncomment to ensure new_tcb is not NULL (for debugging).

    new_tcb->ptcb = ptcb;            // Link the new TCB to the PTCB.
    ptcb->tcb = new_tcb;             // Ensure the PTCB points to the new TCB.
    ptcb->tcb->owner_pcb = new_tcb->owner_pcb; // Set the TCB's owner PCB to the new TCB's owner.

    // Initialize the thread list node in the PTCB.
    rlnode_init(&ptcb->ptcb_list_node, ptcb); // Prepare the PTCB node for insertion into the process's thread list.
    rlist_push_back(&CURPROC->ptcb_list, &ptcb->ptcb_list_node); // Add the PTCB to the process's thread list.

    // Wake up the new thread, signaling it to begin execution.
    wakeup(ptcb->tcb);

    // Return the thread ID of the newly created PTCB.
    return (Tid_t)ptcb;

  }else

	return NOTHREAD;
}

/**
  @brief Return the Tid of the current thread.
 */
Tid_t sys_ThreadSelf()
{
	return (Tid_t) cur_thread();
}

  /**
  @brief Join the given thread.
  */
  int sys_ThreadJoin(Tid_t tid, int* exitval)
  {
  // Create a local PTCB pointer for efficiency.
  PTCB* ptcb = find_ptcb(tid);  // Use find_ptcb to locate the PTCB associated with the given thread ID.

  // Ensure the thread isn't trying to join itself and that the PTCB exists.
  if ((Tid_t)CURTHREAD == tid || ptcb == NULL) {
    return -1;  // Return -1 if the current thread is trying to join itself or if no valid PTCB was found.
}

  // Check if the thread has already exited and is detached; if so, joining is not allowed.
  if (ptcb->exited == 1 && ptcb->detached == 1) {
    return -1;  // Return -1 if the thread is both exited and detached (joining is not possible).
}

  // Increase the reference count since this thread is waiting on the PTCB.
  ptcb->ref_count++;

  // Wait until the thread has exited or is detached.
  while (ptcb->exited != 1 && ptcb->detached != 1) {
    kernel_wait(&ptcb->exit_cv, SCHED_USER);  // Wait on the thread's exit condition variable until it exits or detaches.
}

  // Decrement the reference count after exiting the loop, as there is one less thread waiting on this PTCB.
  ptcb->ref_count--;

  // Set the exit value if requested.
  if (exitval != NULL) {
    exitval = &ptcb->exit_val;  // Assign the thread's exit value to the provided exitval pointer.
} else {
    exitval = NULL;  // Otherwise, leave exitval as NULL.
}

  // If no other thread is waiting on the exit condition variable, clean up the PTCB.
  if (ptcb->ref_count == 0) {  // If the reference count is zero, meaning no threads are waiting,
    rlist_remove(&ptcb->ptcb_list_node);  // Remove the PTCB from the process's thread list.
    free(ptcb);  // Free the memory allocated for the PTCB.
}

	return 0;
}

/**
  @brief Detach the given thread.
  */
int sys_ThreadDetach(Tid_t tid)
{
  // If the id of the current is not valid return -1
  if(tid == NOTHREAD)
    return -1;

  PCB* curproc = CURPROC;

  PTCB ptcb = (PTCB)tid;

  //Search the list for the id of the current thread 

  rlnode* node = rlist_find(&curproc->ptcb_list,ptcb,NULL);

  //If the id is not on the list return false 
  if(node==NULL)
    return -1;
  //If the current thread is exited return false
  if(node->ptcb->exited==1){
    return -1;
    
  //else if the thread is detached signal a kernel condition to all waiters.
  }else{
    node -> ptcb -> detached = 1;
    kernel_broadcast(&node->ptcb->exit_cv);
    return 0;
}

}

/**
  @brief Terminate the current thread.
  */
void sys_ThreadExit(int exitval)
{

  // Retrieve the current PTCB (Process Thread Control Block) using the current TCB (Thread Control Block).
PTCB* ptcb = CURTHREAD->ptcb;

// Mark the thread as exited and set the exit value.
ptcb->exited = 1;                  // Set exited status to 1, indicating the thread has completed.
ptcb->exit_val = exitval;          // Store the exit value provided to the thread.
kernel_broadcast(&ptcb->exit_cv);  // Broadcast to wake up any threads waiting on this thread's exit condition variable.

// Check reference count and thread list.
if (ptcb->ref_count == 0) {
    rlist_remove(&ptcb->ptcb_list_node); // If no other threads are waiting, remove this PTCB from the thread list.
}

// If thread count is zero, perform full cleanup similar to process exit (like sys_exit).
if (CURPROC->thread_count == 0) {
    PCB *curproc = CURPROC;  // Cache the current process's PCB for efficiency.

    /* Clean up process resources (e.g., arguments, file descriptors, child processes). */
    if (curproc->args) {
        free(curproc->args);      // Free allocated memory for arguments if any.
        curproc->args = NULL;     // Set args pointer to NULL to avoid dangling references.
    }


    // Clean up the File ID Table (FIDT).
    for (int i = 0; i < MAX_FILEID; i++) {
        if (curproc->FIDT[i] != NULL) {
            FCB_decref(curproc->FIDT[i]); // Decrease reference count for each file descriptor.
            curproc->FIDT[i] = NULL;      // Set the FIDT entry to NULL after cleanup.
        }
    }

    // Reparent any children of the exiting process to the initial task (process ID 1).
    PCB* initpcb = get_pcb(1);  // Get PCB of the initial task.
    while (!is_rlist_empty(&curproc->children_list)) {
        rlnode* child = rlist_pop_front(&curproc->children_list); // Remove each child from the exiting process.
        child->pcb->parent = initpcb;                             // Reassign the child's parent to the initial task.
        rlist_push_front(&initpcb->children_list, child);         // Add the child to the initial task's children list.
    }

    // Move exited children to the initial task’s exited list and notify the initial task.
    if (!is_rlist_empty(&curproc->exited_list)) {
        rlist_append(&initpcb->exited_list, &curproc->exited_list); // Append all exited children to the initial task’s exited list.
        kernel_broadcast(&initpcb->child_exit);                     // Signal the initial task about exited children.
    }

    // Add this process to its parent’s exited list if it has a parent.
    if (curproc->parent != NULL) {
        rlist_push_front(&curproc->parent->exited_list, &curproc->exited_node); // Add this process to the parent’s exited list.
        kernel_broadcast(&curproc->parent->child_exit);                         // Notify the parent about the exit.
    }

    // Disconnect the main thread from the current process.
    curproc->main_thread = NULL;

    // Mark the process state as ZOMBIE to indicate it has exited.
    curproc->pstate = ZOMBIE;
}

    // Set the exit value for the process and decrease the thread count.
    CURPROC->exitval = exitval;       // Update the process exit value.
    CURPROC->thread_count--;          // Decrement the count of threads in the current process.

    // Put the current thread to sleep as it has finished execution.
    kernel_sleep(EXITED, SCHED_USER); // Transition the thread to a sleeping state after exit.

}


 
